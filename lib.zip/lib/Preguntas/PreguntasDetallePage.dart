import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PreguntasDetallePage extends StatelessWidget {
  final String preguntaId;

  PreguntasDetallePage({required this.preguntaId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle de la Pregunta'),
        backgroundColor: Color(0xFF4B7342), // Cambio de color de la barra de navegación
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('Preguntas')
                  .doc(preguntaId)
                  .collection('Respuestas')
                  .orderBy('fecha', descending: true)
                  .snapshots(),
              builder: (context, AsyncSnapshot
              <QuerySnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Error: ${snapshot.error}',
                      style: TextStyle(color: Colors.red), // Cambio de color del texto de error
                    ),
                  );
                }
                if (snapshot.data!.docs.isEmpty) {
                  return Center(
                    child: Text(
                      'No hay respuestas disponibles para esta pregunta.',
                      style: TextStyle(color: Colors.black87), // Cambio de color del texto de información
                    ),
                  );
                }
                return ListView.builder(
                  itemCount: snapshot.data?.docs.length,
                  itemBuilder: (context, index) {
                    var respuesta = snapshot.data?.docs[index];
                    return ListTile(
                      title: Text(respuesta?['respuesta']),
                      subtitle: Text(
                        'Usuario: ${respuesta?['UID']}',
                        style: TextStyle(color: Colors.black87), // Cambio de color del texto del usuario
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SizedBox(height: 10), // Añadir espacio entre la lista y el botón
          ElevatedButton(
            onPressed: () {
              _agregarRespuesta(context, preguntaId); // Pasar el ID de la pregunta al método
            },
            child: Text('Responder'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF4B7342), // Cambio de color del botón
            ),
          ),
        ],
      ),
    );
  }

  void _agregarRespuesta(BuildContext context, String preguntaId) {
    // Implementa la lógica para agregar una respuesta asociada a la pregunta
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String respuestaText = ''; // Variable para almacenar la respuesta

        return AlertDialog(
          title: Text('Agregar Respuesta'),
          content: TextField(
            // Aquí puedes personalizar el campo de texto según tus necesidades
            decoration: InputDecoration(
              hintText: 'Ingresa tu respuesta aquí',
            ),
            onChanged: (value) {
              respuestaText = value; // Actualizar la respuesta cuando el texto cambie
            },
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                // Verificar si la respuesta no está vacía
                if (respuestaText.isNotEmpty) {
                  // Guardar la respuesta en la base de datos
                  FirebaseFirestore.instance
                      .collection('Preguntas')
                      .doc(preguntaId)
                      .collection('Respuestas')
                      .add({
                    'respuesta': respuestaText,
                    'UID': FirebaseAuth.instance.currentUser?.uid, // Agregar el UID del usuario actual
                    'fecha': DateTime.now(),
                  });

                  // Cerrar el diálogo después de guardar la respuesta
                  Navigator.pop(context);
                }
              },
              child: Text('Enviar'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF4B7342), // Cambio de color del botón
              ),
            ),
          ],
        );
      },
    );
  }
}
