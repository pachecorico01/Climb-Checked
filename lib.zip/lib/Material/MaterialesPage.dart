import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'AgregarMaterialPage.dart';
import 'MaterialDetallePage.dart';
import 'AgregarRevisionPage.dart';

class Material {
  final String nombre;
  final String tipo;

  Material({required this.nombre, required this.tipo});
}

class MaterialesPage extends StatefulWidget {
  final String equipoNombre;

  MaterialesPage({required this.equipoNombre});

  @override
  _MaterialesPageState createState() => _MaterialesPageState();
}

class _MaterialesPageState extends State<MaterialesPage> {
  List<Material> materiales = []; // Lista para almacenar los materiales

  @override
  void initState() {
    super.initState();
    _cargarMateriales();
  }

  void _cargarMateriales() {
    // Consultar los materiales asociados al equipo específico
    FirebaseFirestore.instance
        .collection('materiales')
        .where('equipoNombre', isEqualTo: widget.equipoNombre)
        .get()
        .then((querySnapshot) {
      setState(() {
        materiales = querySnapshot.docs.map((doc) {
          return Material(
            nombre: doc['nombre'],
            tipo: doc['tipo'],
          );
        }).toList();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    // Organizar los materiales por categorías
    Map<String, List<Material>> materialesPorCategoria = {};
    for (var material in materiales) {
      if (!materialesPorCategoria.containsKey(material.tipo)) {
        materialesPorCategoria[material.tipo] = [];
      }
      materialesPorCategoria[material.tipo]!.add(material);
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Materiales de ${widget.equipoNombre}'),
        backgroundColor: Color(0xFFFAEDE4), // Cambio de color de fondo del appbar
      ),
      body: Container(
        color: Color(0xFFFAEDE4), // Color de fondo de la pantalla
        child: ListView.builder(
          itemCount: materialesPorCategoria.length,
          itemBuilder: (context, index) {
            String categoria = materialesPorCategoria.keys.elementAt(index);
            List<Material> materialesCategoria = materialesPorCategoria[categoria]!;
            return ExpansionTile(
              title: Text(categoria, style: TextStyle(color: Color(0xFF4B7342))), // Cambio de color del texto
              children: materialesCategoria.map((material) {
                return ListTile(
                  title: Text(material.nombre),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>
                          MaterialDetallePage(materialNombre: material.nombre)),
                    );
                  },
                  // Botón para acceder al formulario de revisión
                  trailing: IconButton(
                    icon: Icon(Icons.edit),
                    // Cambia el icono según tus necesidades
                    onPressed: () async {
                      // Navega a la página de revisión pasando la categoría de material
                      String? fechaProximaRevision = await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) =>
                            AgregarRevisionPage(categoriaMaterial: categoria)),
                      );
                      // Verifica si se devolvió una fecha de próxima revisión
                      if (fechaProximaRevision != null) {
                        // Actualiza la interfaz si es necesario
                      }
                    },
                  ),
                );
              }).toList(),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _agregarMaterial(context);
        },
        child: Icon(Icons.add),
        backgroundColor: Color(0xFF4B7342), // Cambio de color del botón flotante
      ),
    );
  }

  void _agregarMaterial(BuildContext context) async {
    final nuevoMaterial = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AgregarMaterialPage(equipoNombre: widget.equipoNombre)),
    );
    if (nuevoMaterial != null) {
      // Aquí debemos guardar el nuevo material en Firestore
      FirebaseFirestore.instance.collection('materiales').add({
        'nombre': nuevoMaterial['nombre'],
        'tipo': nuevoMaterial['tipo'],
        'modelo': nuevoMaterial['modelo'],
        'fechaCompra': nuevoMaterial['fechaCompra'],
        'fechaProximaRevision': nuevoMaterial['fechaProximaRevision'], // Agregar la fecha de próxima revisión
        'imagePath': nuevoMaterial['imagePath'],
        'equipoNombre': widget.equipoNombre, // Agregar el nombre del equipo
      }).then((_) {
        // Después de agregar el material, actualizamos la lista de materiales
        _cargarMateriales();
      });
    }
  }
}
