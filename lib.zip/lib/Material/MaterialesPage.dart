import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'AgregarMaterialPage.dart';
import 'MaterialDetallePage.dart';
import 'AgregarRevisionPage.dart';

class Material {
  final String id;
  final String nombre;
  final String tipo;
  final String modelo;
  final String fechaCompra;
  final String fechaProximaRevision;
  final String imagePath;

  Material({
    required this.id,
    required this.nombre,
    required this.tipo,
    required this.modelo,
    required this.fechaCompra,
    required this.fechaProximaRevision,
    required this.imagePath,
  });
}

class MaterialesPage extends StatefulWidget {
  final String equipoNombre;

  MaterialesPage({required this.equipoNombre});

  @override
  _MaterialesPageState createState() => _MaterialesPageState();
}

class _MaterialesPageState extends State<MaterialesPage> {
  Future<List<Material>> _obtenerMateriales() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('materiales')
        .where('equipoNombre', isEqualTo: widget.equipoNombre)
        .get();

    return querySnapshot.docs.map((doc) {
      return Material(
        id: doc.id,
        nombre: doc['nombre'],
        tipo: doc['tipo'],
        modelo: doc['modelo'],
        fechaCompra: doc['fechaCompra'],
        fechaProximaRevision: doc['fechaProximaRevision'],
        imagePath: doc['imagePath'],
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Materiales de ${widget.equipoNombre}'),
        backgroundColor: Color(0xFFFAEDE4),
      ),
      body: Container(
        color: Color(0xFFFAEDE4),
        child: FutureBuilder<List<Material>>(
          future: _obtenerMateriales(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error al cargar los materiales'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No hay materiales disponibles'));
            } else {
              Map<String, List<Material>> materialesPorCategoria = {};
              for (var material in snapshot.data!) {
                if (!materialesPorCategoria.containsKey(material.tipo)) {
                  materialesPorCategoria[material.tipo] = [];
                }
                materialesPorCategoria[material.tipo]!.add(material);
              }

              return ListView.builder(
                itemCount: materialesPorCategoria.length,
                itemBuilder: (context, index) {
                  String categoria = materialesPorCategoria.keys.elementAt(index);
                  List<Material> materialesCategoria = materialesPorCategoria[categoria]!;
                  return ExpansionTile(
                    title: Text(categoria, style: TextStyle(color: Color(0xFF4B7342))),
                    children: materialesCategoria.map((material) {
                      return ListTile(
                        title: Text(material.nombre),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => MaterialDetallePage(
                                materialId: material.id,
                                materialNombre: material.nombre,
                                materialTipo: material.tipo,
                                materialModelo: material.modelo,
                                materialFechaCompra: material.fechaCompra,
                                materialFechaProximaRevision: material.fechaProximaRevision,
                                materialImagePath: material.imagePath,
                              ),
                            ),
                          );
                        },
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () async {
                                String? fechaProximaRevision = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => AgregarRevisionPage(
                                      categoriaMaterial: categoria,
                                      materialId: material.id,
                                    ),
                                  ),
                                );
                                if (fechaProximaRevision != null) {
                                  setState(() {});
                                }
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () {
                                _eliminarMaterial(material.id);
                              },
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  );
                },
              );
            }
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _agregarMaterial(context);
        },
        child: Icon(Icons.add),
        backgroundColor: Color(0xFF4B7342),
      ),
    );
  }

  void _agregarMaterial(BuildContext context) async {
    final nuevoMaterial = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AgregarMaterialPage(equipoNombre: widget.equipoNombre)),
    );
    if (nuevoMaterial != null) {
      setState(() {
        _obtenerMateriales(); // Actualizar la lista de materiales después de agregar uno nuevo
      });
    }
  }

  void _eliminarMaterial(String materialId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Eliminar Material"),
          content: Text("¿Estás seguro de que quieres eliminar este material?"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Cancelar"),
            ),
            TextButton(
              onPressed: () {
                FirebaseFirestore.instance.collection('materiales').doc(materialId).delete().then((_) {
                  setState(() {
                    _obtenerMateriales(); // Actualizar la lista de materiales después de eliminar uno
                  });
                  Navigator.of(context).pop();
                });
              },
              child: Text("Eliminar"),
            ),
          ],
        );
      },
    );
  }
}
