import 'package:flutter/material.dart';

class MaterialDetallePage extends StatelessWidget {
  final String materialNombre;

  MaterialDetallePage({required this.materialNombre});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalles del Material'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Nombre: $materialNombre',
              style: TextStyle(fontSize: 20),
            ),
            // Agrega más características según sea necesario
          ],
        ),
      ),
    );
  }
}
