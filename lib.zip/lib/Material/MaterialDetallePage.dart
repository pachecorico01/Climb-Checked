import 'package:flutter/material.dart';

class MaterialDetallePage extends StatelessWidget {
  final String materialId;
  final String materialNombre;
  final String materialTipo;
  final String materialModelo;
  final String materialFechaCompra;
  final String materialFechaProximaRevision;
  final String materialImagePath;

  MaterialDetallePage({
    required this.materialId,
    required this.materialNombre,
    required this.materialTipo,
    required this.materialModelo,
    required this.materialFechaCompra,
    required this.materialFechaProximaRevision,
    required this.materialImagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          materialNombre,
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Color(0xFFFAEDE4),
        elevation: 0,
      ),
      backgroundColor: Color(0xFFFAEDE4),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 1,
                blurRadius: 2,
                offset: Offset(0, 1),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildImage(materialImagePath),
              SizedBox(height: 20),
              _buildInfo('Nombre:', materialNombre),
              _buildInfo('Tipo:', materialTipo),
              _buildInfo('Modelo:', materialModelo),
              _buildInfo('Fecha de Compra:', materialFechaCompra),
              _buildInfo('Fecha Próxima Revisión:', materialFechaProximaRevision),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfo(String label, String value) {
    return Text(
      '$label $value',
      style: TextStyle(fontSize: 16, color: Colors.black87),
    );
  }

  Widget _buildImage(String imageUrl) {
    if (imageUrl.isNotEmpty) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Image.network(
          imageUrl,
          width: double.infinity,
          fit: BoxFit.cover,
        ),
      );
    } else {
      return SizedBox.shrink();
    }
  }
}
