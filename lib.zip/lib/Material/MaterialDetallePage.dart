import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MaterialDetallePage extends StatelessWidget {
  final String materialId;
  final String materialNombre;
  final String materialTipo;
  final String materialModelo;
  final String materialFechaCompra;
  final String materialFechaProximaRevision;
  final String materialImagePath;

  MaterialDetallePage({
    required this.materialId,
    required this.materialNombre,
    required this.materialTipo,
    required this.materialModelo,
    required this.materialFechaCompra,
    required this.materialFechaProximaRevision,
    required this.materialImagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(materialNombre),
        backgroundColor: Color(0xFFFAEDE4),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Nombre: $materialNombre'),
            Text('Tipo: $materialTipo'),
            Text('Modelo: $materialModelo'),
            Text('Fecha de Compra: $materialFechaCompra'),
            Text('Fecha Próxima Revisión: $materialFechaProximaRevision'),
            Image.network(materialImagePath),  // Assuming imagePath is a URL
          ],
        ),
      ),
    );
  }
}
