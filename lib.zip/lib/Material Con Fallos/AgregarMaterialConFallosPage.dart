import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';

class AgregarMaterialConFallosPage extends StatefulWidget {
  @override
  _AgregarMaterialConFallosPageState createState() =>
      _AgregarMaterialConFallosPageState();
}

class _AgregarMaterialConFallosPageState
    extends State<AgregarMaterialConFallosPage> {
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController marcaController = TextEditingController();
  final TextEditingController modeloController = TextEditingController();
  final TextEditingController tipoController = TextEditingController();
  final TextEditingController fechaFabricacionController =
  TextEditingController();
  final TextEditingController numeroSerieController = TextEditingController();
  final TextEditingController descripcionFalloController =
  TextEditingController(); // Nuevo controlador para la descripción del fallo
  File? _image;

  Future<void> _getImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      }
    });
  }

  void agregarMaterialConFallo() {
    if (nombreController.text.isNotEmpty &&
        marcaController.text.isNotEmpty &&
        modeloController.text.isNotEmpty &&
        tipoController.text.isNotEmpty &&
        fechaFabricacionController.text.isNotEmpty &&
        numeroSerieController.text.isNotEmpty) {
      FirebaseFirestore.instance.collection('materiales_con_fallos').add({
        'nombre': nombreController.text,
        'marca': marcaController.text,
        'modelo': modeloController.text,
        'tipo': tipoController.text,
        'fecha_fabricacion': fechaFabricacionController.text,
        'numero_serie': numeroSerieController.text,
        'descripcion_fallo': descripcionFalloController.text,
        // Nuevo campo para la descripción del fallo
        'imagen_url': '',
        // Aquí puedes guardar la URL de la imagen en Firebase Storage
        // Agrega más campos aquí según sea necesario
      });
    } else {
      // Mostrar una snackbar informando al usuario sobre los campos obligatorios faltantes
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Por favor complete todos los campos.'),
          action: SnackBarAction(
            label: 'OK',
            onPressed: () {},
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agregar Material con Fallos'),
        backgroundColor: Color(0xFFFAEDE4), // Color de fondo del app bar
      ),
      body: Container(
        color: Color(0xFFFAEDE4), // Color de fondo uniforme
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            // Envolver el contenido del cuerpo en un SingleChildScrollView para permitir desplazamiento si es necesario
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: nombreController,
                  decoration: InputDecoration(
                      labelText: 'Nombre',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: marcaController,
                  decoration: InputDecoration(
                      labelText: 'Marca',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))), // Cambio del color de la etiqueta a verde
                ),
                SizedBox(height: 10),
                TextField(
                  controller: modeloController,
                  decoration: InputDecoration(
                      labelText: 'Modelo',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: tipoController,
                  decoration: InputDecoration(
                      labelText: 'Tipo',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: fechaFabricacionController,
                  decoration: InputDecoration(
                      labelText: 'Fecha de fabricación',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: numeroSerieController,
                  decoration: InputDecoration(
                      labelText: 'Número de serie',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: descripcionFalloController,
                  // Asignar el controlador para el campo de descripción del fallo
                  decoration: InputDecoration(
                      labelText: 'Descripción del fallo',
                      labelStyle: TextStyle(color: Color(0xFF4B7342))),
                  // Etiqueta del campo de texto
                  maxLines: null,
                  // Permitir múltiples líneas para la descripción
                ),
                SizedBox(height: 10),
                _image == null
                    ? ElevatedButton(
                  onPressed: _getImage,
                  child: Text(
                    'Seleccionar Imagen',
                    style: TextStyle(color: Colors.white),
                    // Color del texto blanco
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF4B7342),
                    // Color del botón
                  ),
                )
                    : Image.file(_image!),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    agregarMaterialConFallo();
                    // Volver a la pantalla anterior después de agregar el material
                    Navigator.pop(context);
                  },
                  child: Text(
                    'Agregar Material con Fallo',
                    style: TextStyle(color: Colors.white),
                    // Color del texto blanco
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF4B7342),
                    // Color del botón
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
