import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../menu.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> signIn(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      //navega a la pantalla de menú
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Menu()),
        );

    } catch (e) {
      // Mostrar mensaje de error al usuario
      String errorMessage = '';
      if (e is FirebaseAuthException) {
        switch (e.code) {
          case 'user-not-found':
            errorMessage = 'Usuario no encontrado.';
            break;
          case 'wrong-password':
            errorMessage = 'Contraseña incorrecta.';
            break;
          default:
            errorMessage = 'Error de inicio de sesión: ${e.message}';
        }
      } else {
        errorMessage = 'Error de inicio de sesión: ${e.toString()}';
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errorMessage),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFFAEDE4), // Mismo color de fondo que la pantalla de registro
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Image.asset(
                'assets/logo.png', // Ruta de la imagen del logo
                height: 300, // Altura del logo
                fit: BoxFit.contain, // Ajustar el tamaño del logo al contenedor
              ),
              SizedBox(height: 20.0),
              Text(
                'Inicio de sesión', // Indicación de que estás en la pantalla de inicio de sesión
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF4B7342), // Color del texto verde
                ),
              ),
              SizedBox(height: 20.0),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Correo electrónico',
                  labelStyle: TextStyle(color: Color(0xFF4B7342)), // Color del texto de la etiqueta en verde
                ),
                style: TextStyle(color: Color(0xFF4B7342)), // Color del texto del campo de entrada en verde
              ),
              SizedBox(height: 20.0),
              TextField(
                controller: passwordController,
                decoration: InputDecoration(
                  labelText: 'Contraseña',
                  labelStyle: TextStyle(color: Color(0xFF4B7342)), // Color del texto de la etiqueta en verde
                ),
                style: TextStyle(color: Color(0xFF4B7342)), // Color del texto del campo de entrada en verde
                obscureText: true,
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () => signIn(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF4B7342), // Color del botón verde
                ),
                child: Text(
                  'Iniciar sesión',
                  style: TextStyle(
                    color: Colors.white, // Color del texto en el botón blanco
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
