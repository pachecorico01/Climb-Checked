import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'login.dart';

class ProfileScreen extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController newPasswordController = TextEditingController();

  Future<void> _changePassword(BuildContext context) async {
    try {
      await _auth.currentUser?.updatePassword(newPasswordController.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Contraseña cambiada con éxito.'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      print("Error during password change: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error al cambiar la contraseña: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      await _auth.signOut();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    } catch (e) {
      print("Error during sign out: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi Perfil'),
        backgroundColor: Color(0xFF4B7342),
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('Usuarios').doc(_auth.currentUser?.uid).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return Center(
              child: Text('Usuario no encontrado'),
            );
          }
          var userData = snapshot.data!.data() as Map<String, dynamic>;
          String username = userData['nombre'] ?? ''; // Obtener el nombre de usuario
          return Container(
            color: Color(0xFFFAEDE4), // Color de fondo uniforme
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Nombre de Usuario: $username', // Mostrar el nombre de usuario
                      style: TextStyle(fontSize: 20, color: Colors.black), // Estilo de texto uniforme
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Cambiar Contraseña',
                      style: TextStyle(fontSize: 20, color: Colors.black), // Estilo de texto uniforme
                    ),
                    SizedBox(height: 20),
                    TextField(
                      controller: newPasswordController,
                      decoration: InputDecoration(
                        labelText: 'Nueva Contraseña',
                      ),
                      obscureText: true,
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () => _changePassword(context),
                      child: Text('Guardar Cambios'),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () => _signOut(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      child: Text('Cerrar Sesión'),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
