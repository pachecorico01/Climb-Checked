import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MaterialConFallosDetalle extends StatelessWidget {
  final String docId;

  MaterialConFallosDetalle({required this.docId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalles del Material con Fallos'),
        backgroundColor: Color(0xFF4B7342), // Color del AppBar
      ),
      backgroundColor: Color(0xFFFAEDE4), // Color de fondo de la pantalla
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('materiales_con_fallos').doc(docId).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final data = snapshot.data!.data() as Map<String, dynamic>;

            return Padding(
              padding: EdgeInsets.all(20.0),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 1,
                      blurRadius: 2,
                      offset: Offset(0, 1), // changes position of shadow
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInfo('Nombre:', data['nombre']),
                    SizedBox(height: 10),
                    _buildInfo('Marca:', data['marca']),
                    SizedBox(height: 10),
                    _buildInfo('Modelo:', data['modelo']),
                    SizedBox(height: 10),
                    _buildInfo('Tipo:', data['tipo']),
                    SizedBox(height: 10),
                    _buildInfo('Fecha de Fabricación:', data['fecha_fabricacion']),
                    SizedBox(height: 10),
                    _buildInfo('Número de Serie:', data['numero_serie']),
                    SizedBox(height: 10),
                    _buildInfo('Descripción del Fallo:', data['descripcion_fallo']), // Mostrar la descripción del fallo
                    SizedBox(height: 10),
                    _buildImage(data['imagen_url']), // Mostrar la imagen
                    SizedBox(height: 10),
                    // Agrega más detalles aquí según sea necesario
                  ],
                ),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildInfo(String label, String value) {
    return Text(
      '$label $value',
      style: TextStyle(fontSize: 16, color: Color(0xFF4B7342)),
    );
  }

  Widget _buildImage(String imageUrl) {
    if (imageUrl.isNotEmpty) {
      return Image.network(
        imageUrl,
        width: 200, // Ancho de la imagen
        height: 200, // Alto de la imagen
        fit: BoxFit.cover, // Ajuste de la imagen
      );
    } else {
      return SizedBox.shrink(); // Retorna un widget vacío si no hay URL de imagen
    }
  }
}
